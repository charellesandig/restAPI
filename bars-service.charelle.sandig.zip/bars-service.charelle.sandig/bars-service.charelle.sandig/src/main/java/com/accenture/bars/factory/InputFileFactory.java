package com.accenture.bars.factory;

import com.accenture.bars.exception.BarsException;
import com.accenture.bars.file.AbstractInputFile;
import com.accenture.bars.file.CSVInputFileImpl;
import com.accenture.bars.file.TextInputFileImpl;
import org.apache.commons.io.FilenameUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;

@Service
@Component
public class InputFileFactory {
    private static InputFileFactory factory;

    //create a private constructor
    private InputFileFactory() {
    }

    public static InputFileFactory getInstance() {
        if (factory == null) {
            factory = new InputFileFactory();
        }
        return factory;
    }

    public AbstractInputFile getInputFile(File file) throws BarsException {

        String fileName = FilenameUtils.getExtension(String.valueOf(file));

        if (fileName.endsWith("txt")) {
            return new TextInputFileImpl();
        } else if (fileName.endsWith("csv")) {
            return new CSVInputFileImpl();
        } else {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    BarsException.FILE_NOT_SUPPORTED);
        }
    }
}
