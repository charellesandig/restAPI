package com.accenture.bars.controller;

import com.accenture.bars.domain.Record;
import com.accenture.bars.domain.Request;
import com.accenture.bars.entity.Billing;
import com.accenture.bars.exception.BarsException;
import com.accenture.bars.factory.InputFileFactory;
import com.accenture.bars.file.AbstractInputFile;
import com.accenture.bars.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

//Service part
@Component
@Service
public class FileProcessor {
    @Autowired
    private BillingRepository billingRepository; //uml

    public FileProcessor(BillingRepository billingRepository) {
        this.billingRepository = billingRepository;
    }

    public List<Request> execute(File file) throws Exception {
        if (file.exists()) {
            InputFileFactory inputFileFactory = InputFileFactory.getInstance();
            AbstractInputFile abstractInputFile =
                    inputFileFactory.getInputFile(file);
            abstractInputFile.setFile(file);
            abstractInputFile.readFile();
            List<Request> requests = abstractInputFile.readFile();
            return requests;
        } else {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    BarsException.FILE_NOT_SUPPORTED);
        }
    }

    public List<Record> retrieveRecordfromDB(List<Request> requests)
            throws BarsException {
        List<Record> records = new ArrayList<>(); //**
        List<Billing> billings = new ArrayList<>(); //**
        for (Request request : requests) {
            Billing billing = billingRepository
                    .findByBillingCycleAndStartDateAndEndDate(
                            request.getBillingCycle(),
                            request.getStartDate(),
                            request.getEndDate());
            if (billing != null) {
                billings.add(billing);
            }
        }
        if (billings.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    BarsException.NO_RECORDS_TO_WRITE);
        } else {
            for (Billing billing : billings) {
                Record record = new Record();
                record.setBillingCycle(billing.getBillingCycle());
                record.setStartDate(billing.getStartDate());
                record.setEndDate(billing.getEndDate());
                record.setAccountName(billing.getAccountId().getAccountName());
                record.setAmount(billing.getAmount());
                record.setFirstName(billing.getAccountId()
                        .getCustomerId().getFirstName());
                record.setLastName(billing.getAccountId()
                        .getCustomerId().getLastName());
                records.add(record);
            }
        }
        return records;
    }
}
