package com.accenture.bars.domain;
import com.accenture.bars.exception.BarsException;
import com.accenture.bars.file.TextInputFileImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDate;
import java.util.Objects;
public class Request {


    private static final Logger logger =
            LoggerFactory.getLogger(TextInputFileImpl.class);
    private int billingCycle;
    private LocalDate startDate;
    private LocalDate endDate;
    public Request(){
    }
    public Request(int billingCycle, LocalDate startDate, LocalDate endDate) {
        this.billingCycle = billingCycle;
        this.startDate = startDate;
        this.endDate = endDate;
    }
    public int getBillingCycle() {
        return billingCycle;
    }
    public void setBillingCycle(int billingCycle) {
        this.billingCycle = billingCycle;
    }
    public LocalDate getStartDate() {
        return startDate;
    }
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
    public LocalDate getEndDate() {
        return endDate;
    }
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }



    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Request other = (Request) obj;
        if(billingCycle != other.billingCycle ||
                !Objects.equals(endDate, other.endDate)
                || !Objects.equals(startDate, other.startDate)){
            logger.info("Request " + BarsException.NO_SUPPORTED_FILE);
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, BarsException.NO_SUPPORTED_FILE);
        }
        return billingCycle == other.billingCycle &&
                Objects.equals(endDate, other.endDate)
                && Objects.equals(startDate, other.startDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getBillingCycle(),
                getStartDate(),
                getEndDate());
    }

}