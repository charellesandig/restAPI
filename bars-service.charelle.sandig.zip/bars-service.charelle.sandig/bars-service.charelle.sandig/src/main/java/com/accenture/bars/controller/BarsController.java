package com.accenture.bars.controller;

import com.accenture.bars.domain.Record;
import com.accenture.bars.domain.Request;
import com.accenture.bars.exception.BarsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.util.List;

@RestController
public class BarsController {

    private static final Logger logger=
            LoggerFactory.getLogger(BarsController.class);

    @Autowired
    private FileProcessor fileProcessor;

    @GetMapping("/bars")
    public List<Record> requestBilling(@RequestParam("filePath")
       String testCases) throws Exception {
        logger.info("FilePath: " + testCases);
        File file = new File("C:\\BARS_TEST\\" + testCases); //**
        try {
            if (testCases.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        BarsException.PATH_DOES_NOT_EXIST);
        }
            List<Request> requests = fileProcessor.execute(file); //**
            List<Record> records = fileProcessor.retrieveRecordfromDB(requests);
            return records;
        }catch (BarsException exc){
            logger.error("",exc);
            throw exc;
        }
    }
}
