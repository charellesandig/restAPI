package com.accenture.bars.file;

import com.accenture.bars.domain.Request;
import com.accenture.bars.exception.BarsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class CSVInputFileImpl extends AbstractInputFile {
    private static final Logger logger =
            LoggerFactory.getLogger(CSVInputFileImpl.class);

    @Override
    public List<Request> readFile() throws IOException,
            BarsException {
        logger.info("File path: " + getFile() + " ");
        List<Request> requests = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyy");

        // initialize billingCycle, startDate and endDate
        int billingCycle;
        LocalDate startDate;
        LocalDate endDate;

        //file access
        FileReader fileReader = new FileReader(getFile().getAbsolutePath());
       //then file read
        try (BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            String eachLine;
            int row = 1;

            if (getFile().length() != 0) {
                while ((eachLine = bufferedReader.readLine()) != null) {
                    Request request = new Request();
                    String[] csvFile = eachLine.split(",");
                    try {
                        billingCycle = Integer.parseInt(csvFile[0]);
                        if (billingCycle > 0 && billingCycle
                                < GREATER_THAN_MAX_BILLING_CYCLE) {
                            request.setBillingCycle(billingCycle);
                        } else if (billingCycle < 1 || billingCycle
                                > MAX_BILLING_CYCLE) {
                            logger.info("Billing cycle not on range");
                            throw new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST,
                                    BarsException.BILLING_CYCLE_NOT_ON_RANGE
                                            + " " + row);
                        } else {
                            logger.info("Invalid billing cycle");
                            throw new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST,
                                    BarsException.INVALID_BILLING_CYCLE
                                            + " " + row);
                        }
                    } catch (NumberFormatException exc) {
                        logger.info("", exc);

                    }
                    try {
                        startDate = LocalDate.parse(csvFile[1], formatter);
                        request.setStartDate(startDate);
                    } catch (DateTimeParseException exc) {
                        logger.info("Invalid start date format");
                        throw new ResponseStatusException(
                                HttpStatus.BAD_REQUEST,
                                BarsException.INVALID_START_DATE_FORMAT
                                        + " " + row);
                    }
                    try {
                        endDate = LocalDate.parse(
                                csvFile[TWO_BILLING_CYCLE], formatter);
                        request.setEndDate(endDate);
                    } catch (DateTimeParseException exc) {
                        logger.info("Invalid end date format");
                        throw new ResponseStatusException(
                                HttpStatus.BAD_REQUEST,
                                BarsException.INVALID_END_DATE_FORMAT
                                        + " " + row);
                    }
                    requests.add(request);
                    row++;
                }
            } else {
                logger.info("No request(s) to read");
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        BarsException.NO_REQUEST_TO_READ);
            }
            return requests;
        }
    }
}
