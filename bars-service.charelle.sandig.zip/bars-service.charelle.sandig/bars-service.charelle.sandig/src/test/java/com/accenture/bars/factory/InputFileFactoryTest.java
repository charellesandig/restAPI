package com.accenture.bars.factory;

import com.accenture.bars.exception.BarsException;
import com.accenture.bars.file.AbstractInputFile;
import com.accenture.bars.file.CSVInputFileImpl;
import com.accenture.bars.file.TextInputFileImpl;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;

public class InputFileFactoryTest {

    @org.junit.Test
    public void testGetInstance() {
        InputFileFactory factory = InputFileFactory.getInstance();
        assertTrue(factory instanceof InputFileFactory);
    }

    @org.junit.Test
    public void testGetTextInputFile() throws BarsException {
        InputFileFactory factory = InputFileFactory.getInstance();
        AbstractInputFile txtInputFile = factory.getInputFile(
                new File("C:\\BARS\\valid-txt.txt")
        );
        txtInputFile.setFile(new File("C:\\BARS\\valid-txt.txt"));
        assertTrue(txtInputFile instanceof TextInputFileImpl);
    }

    @org.junit.Test
    public void testGetInputFileCsv() throws BarsException {
        InputFileFactory factory = InputFileFactory.getInstance();
        AbstractInputFile csvInputFile = factory.getInputFile(
                new File("C:\\BARS\\valid-csv.csv")
        );
        csvInputFile.setFile(new File("C:\\BARS\\valid-csv.csv"));
        assertTrue(csvInputFile instanceof CSVInputFileImpl);
    }

    @org.junit.Test
    public void testFileNotSupported() throws BarsException {
        InputFileFactory factory = InputFileFactory.getInstance();
        Exception exception = assertThrows(ResponseStatusException.class, () -> {
            factory.getInputFile(
                    new File("C:\\BARS\\unsupported-file.png"));
        });

        String expectedMessage = "400 BAD_REQUEST \"File is not supported for processing.\"";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));

    }
}