package com.accenture.bars.file;
import com.accenture.bars.domain.Request;
import com.accenture.bars.exception.BarsException;
import com.accenture.bars.factory.InputFileFactory;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
public class TextInputFileImplTest {
    @Test
    void testReadValidRequestParameter() throws BarsException, IOException {
        String fileName = "valid-txt.txt";
        String filePath = "C:/BARS_TEST/" + fileName;
        File file = new File(filePath);
        InputFileFactory inputFileFactory = InputFileFactory.getInstance();
        AbstractInputFile abstractInputFile = inputFileFactory.getInputFile(file);
        abstractInputFile.setFile(file);
        List<Request> actual = abstractInputFile.readFile();
        List<Request> expected = new ArrayList<>();
        expected.add(new Request(1, LocalDate.of(2013, 01,
                15), LocalDate.of(2013, 02, 14)));
        expected.add(new Request(1, LocalDate.of(2016, 01,
                15), LocalDate.of(2016, 02, 14)));
        assertEquals(actual, expected);
    }
    @Test
    void testInvalidBillingCycleParameter() throws BarsException, IOException {
        String fileName = "billing-cycle-not-on-range-txt.txt";
        String filePath = "C:/BARS_TEST/" + fileName;
        File file = new File(filePath);
        InputFileFactory inputFileFactory = InputFileFactory.getInstance();
        AbstractInputFile abstractInputFile = inputFileFactory.getInputFile(file);
        try {
            inputFileFactory.getInputFile(file);
        } catch (BarsException exception) {
            String expectedMessage = BarsException.BILLING_CYCLE_NOT_ON_RANGE;
            String actualMessage = exception.getMessage();
            assertTrue(actualMessage.contains(expectedMessage));
        }
    }
    @Test
    void testInvalidStartDateFormatParameter() throws BarsException, IOException {
        String fileName = "invalid-start-date-txt.txt";
        String filePath = "C:/BARS_TEST/" + fileName;
        File file = new File(filePath);
        InputFileFactory inputFileFactory = InputFileFactory.getInstance();
        AbstractInputFile abstractInputFile = inputFileFactory.getInputFile(file);
        try {
            inputFileFactory.getInputFile(file);
        } catch (BarsException exception) {
            String expectedMessage = BarsException.INVALID_START_DATE_FORMAT;
            String actualMessage = exception.getMessage();
            assertTrue(actualMessage.contains(expectedMessage));
        }
    }
    @Test
    void testInvalidEndDateFormatParameter() throws BarsException, IOException {
        String fileName = "invalid-end-date-txt.txt";
        String filePath = "C:/BARS_TEST/" + fileName;
        File file = new File(filePath);
        InputFileFactory inputFileFactory = InputFileFactory.getInstance();
        AbstractInputFile abstractInputFile = inputFileFactory.getInputFile(file);
        try {
            inputFileFactory.getInputFile(file);
        } catch (BarsException exception) {
            String expectedMessage = BarsException.INVALID_END_DATE_FORMAT;
            String actualMessage = exception.getMessage();
            assertTrue(actualMessage.contains(expectedMessage));
        }
    }
}